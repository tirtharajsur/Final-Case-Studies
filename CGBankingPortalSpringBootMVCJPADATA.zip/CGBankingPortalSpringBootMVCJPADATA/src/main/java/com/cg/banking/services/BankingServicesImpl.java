package com.cg.banking.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	@Autowired
	AccountDAO customerData1;
	@Autowired
	TransactionDAO transactions;
	
	private final static float minBalance = 1000;
	private final static int maxInvalidPinAttempts = 3;

	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account customer = customerData1.save(account);
		customer.setPinNumber((long)(Math.random()*10000));
		customer = customerData1.save(account);
		transactions.save(new Transaction(account.getAccountBalance(),"Deposit",customer) );
		return customer;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = getAccountDetails(accountNo);
		if(customers==null)
			throw new AccountNotFoundException("Sorry The Account does not exist!!");
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Sorry The Account is blocked!!");
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		Transaction t = new Transaction(amount, "Deposit", customers);
		this.customerData1.save(customers);
		transactions.save(t);
		
		return customers.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers =null;
		customers = getAccountDetails(accountNo);
		if(customers==null)
			throw new AccountNotFoundException("Sorry The Account does not exist!!");
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Sorry The Account is blocked!!");
		else if(customers.getPinNumber()!=pinNumber) {
			customers.incrementInvalidPinNumberAttemptAttempt();
			System.out.println("Invalid Pin.\n"+(maxInvalidPinAttempts-customers.getInvalidPinNumberAttempt())+" more attempts remaining");
			if((customers.getInvalidPinNumberAttempt()==maxInvalidPinAttempts)){
				customers.setAccountStatus("Blocked");
				throw new AccountBlockedException();
				}
			throw new InvalidPinNumberException("Invalid Pin faced!");
		}
		else if(customers.getAccountBalance()-amount <=minBalance)
			throw new InsufficientAmountException();
		else
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		this.customerData1.save(customers);
		Transaction t = new Transaction(amount, "Withdraw", customers);
		transactions.save(t );
		return customers.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoFrom,long accountNoTo, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo = getAccountDetails(accountNoTo);
		Account customerFrom = getAccountDetails(accountNoFrom);
	
		
		if(customerFrom.getAccountBalance()-transferAmount <=minBalance)
			throw new InsufficientAmountException("Transaction failed due to insufficient balance");
		else if(customerFrom.getPinNumber()!=pinNumber) 
			throw new InvalidPinNumberException("Sorry the Pin is Invalid.");
		else {
			customerFrom.setAccountBalance(customerFrom.getAccountBalance()-transferAmount);
			this.customerData1.save(customerTo);
			this.customerData1.save(customerFrom);
			transactions.save(new Transaction(transferAmount, "Withdraw", customerFrom) );
			transactions.save(new Transaction(transferAmount, "Deposit", customerTo) );
			depositAmount(customerTo.getAccountNo(), transferAmount);
			withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		}
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		
		return customerData1.findById(accountNo).orElseThrow(()-> new AccountNotFoundException("Account Not Found !!"));
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> customers = customerData1.findAll();		
		return customers;
	}

	/*
	 * @Override public List<Transaction> getAccountAllTransaction(long accountNo)
	 * throws BankingServicesDownException, AccountNotFoundException { return
	 * transactions.findAll(accountNo); }
	 */
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers = getAccountDetails(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();		
		return customers.getAccountStatus();
	}
}
