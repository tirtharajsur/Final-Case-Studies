package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Transaction;

/*@Component("transactionDAO")*/
public interface TransactionDAO extends JpaRepository<Transaction,Integer>{
	
	
}
