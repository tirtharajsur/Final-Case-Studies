package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;

@Controller
public class URIController {
	

	
	@RequestMapping(value= {"/", "index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/openAccount")
	public String getOpenAccountPage() {
		return "openAccountPage";
	}
	
	@RequestMapping("/findAccountDetails")
	public String getFindAccountDetailsPage() {
		return "findAccountDetailsPage";
	}
	
	@RequestMapping("/findAllAccountDetails")
	public String getFindAllAccountDetailsPage() {
		return "findAllAccountDetailsPage";
	}
	
	@RequestMapping("/depositAmountDetails")
	public String getdepositAmountDetailsPage() {
		return "depositAmountDetailsPage";
	}
	
	@RequestMapping("/withdrawAmountDetails")
	public String getwithdrawAmountDetailsPage() {
		return "withdrawAmountDetailsPage";
	}
	
	@RequestMapping("/fundTransferAmountDetails")
	public String getfundTransferAmountDetailsPage() {
		return "fundTransferAmountDetailsPage";
	}
	
	
	
	@ModelAttribute
	public Account getAccount() {
		return new Account();
	}

}
