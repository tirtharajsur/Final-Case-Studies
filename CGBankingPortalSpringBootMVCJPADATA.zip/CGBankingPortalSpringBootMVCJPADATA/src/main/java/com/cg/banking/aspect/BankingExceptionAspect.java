package com.cg.banking.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@ControllerAdvice
public class BankingExceptionAspect {
	
	@ExceptionHandler(AccountNotFoundException.class)
	public ModelAndView handelAccountDetailsNotFoundException(Exception e) {
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(BankingServicesDownException.class)
	public ModelAndView handelBankingServicesDownException(Exception e) {
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler( InvalidPinNumberException.class)
	public ModelAndView handelInvalidPinNumberException(Exception e) {
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler( AccountBlockedException.class)
	public ModelAndView handelAccountBlockedException(Exception e) {
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(InsufficientAmountException.class)
	public ModelAndView handelInsufficientAmountException(Exception e) {
		return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
	}
}
