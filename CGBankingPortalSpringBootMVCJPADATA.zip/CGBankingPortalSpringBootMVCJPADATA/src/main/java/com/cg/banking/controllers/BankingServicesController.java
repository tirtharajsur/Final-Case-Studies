package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices bankingServices;
	
	@RequestMapping("/registerAccount")
	public ModelAndView openAccount(@ModelAttribute Account account) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		account = bankingServices.openAccount(account);
		return new ModelAndView("openAccountSuccessPage","account",account);
	}
	
	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo) throws AccountNotFoundException, BankingServicesDownException{
		Account account = bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetailsPage","account",account);
	}
	
	
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAccountDetails() throws AccountNotFoundException, BankingServicesDownException{
		return new ModelAndView("findAllAccountDetailsPage","accounts",bankingServices.getAllAccountDetails());
	}
	
	@RequestMapping("/depositAmount")
	public ModelAndView depositAmount(@RequestParam long accountNo,@RequestParam float amount) throws AccountNotFoundException, BankingServicesDownException,AccountBlockedException{
		bankingServices.depositAmount(accountNo,amount);
		return new ModelAndView("depositAmountDetailsPage","account",bankingServices.getAccountDetails(accountNo));
	}
	
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmount(@RequestParam long accountNo,@RequestParam float amount,@RequestParam long pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(accountNo,amount,pinNumber);
		return new ModelAndView("withdrawAmountDetailsPage","account",bankingServices.getAccountDetails(accountNo));
	}
	
	@RequestMapping("/fundTransferAmount")
	public ModelAndView fundTransfer(@RequestParam long accountNoFrom,@RequestParam long accountNoTo,@RequestParam float amount,@RequestParam long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.fundTransfer(accountNoFrom,accountNoTo,amount,pinNumber);
		ModelAndView ref = new ModelAndView("fundTransferAmountDetailsPage");
		ref.addObject("accountTo", bankingServices.getAccountDetails(accountNoTo));
		ref.addObject("accountFrom", bankingServices.getAccountDetails(accountNoFrom));
		return ref;
	}
	
	
}
