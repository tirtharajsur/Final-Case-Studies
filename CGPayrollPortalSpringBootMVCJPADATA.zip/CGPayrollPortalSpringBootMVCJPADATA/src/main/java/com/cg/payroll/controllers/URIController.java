package com.cg.payroll.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;

@Controller
public class URIController {
	

	
	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/registration")
	public String getRegistrationPAge() {
		return "RegistrationPage";
	}
	
	@RequestMapping("/findAssociateDetails")
	public String getFindAssociateDetailsPage() {
		return "findAssociateDetailsPage";
	}
	
	@RequestMapping("/calculateNetSalary")
	public String getCalculateNetSalaryPage() {
		return "calculateNetSalaryPage";
	}
	
	@RequestMapping("/findAllAssociateDetails")
	public String getFindAllAssociateDetailsPage() {
		return "findAllAssociateDetailsPage";
	}
	
	
	@ModelAttribute
	public Associate getAssociate() {
		return new Associate();
	}

}
